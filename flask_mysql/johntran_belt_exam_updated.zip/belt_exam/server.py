from sasquatchwatch import app
from sasquatchwatch.controllers import sighting_controller
from sasquatchwatch.controllers import user_controller


if __name__ == '__main__':
    app.run(debug=True)
