from ninja import Ninja
from pets import Pet

richie = Pet('Richie', 'Dog',['Fetch', 'Roll over', 'Play dead'], 'Bark bark')

john = Ninja('John', 'Tran', ['Crackers', 'Chips', 'Cookies'], ['Kibbles', 'Steak', ' Chicken'], richie)

john.about()
john.bathe().walk().feed().feed().feed().feed().feed()
john.about()