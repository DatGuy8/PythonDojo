
import random
from flask import Flask, render_template, redirect, session, request


app = Flask(__name__)
app.secret_key = 'myprecious'


@app.route('/', methods=['POST','GET'])
def home():
    if "randomnum" in session:
        pass
    else :
        session['randomnum'] = random.randint(1,100)
    print(f"Random Number is: {session['randomnum']}")
    return render_template('index.html')

@app.route('/isitright', methods=['POST'])
def checkit():
    session['picked'] = int(request.form["guess"])
    guessednumber = session['picked']
    print('Guess Number is', guessednumber)

    if guessednumber == session['randomnum']:
        return redirect('/yougotit')
    elif guessednumber > session['randomnum']:
        return redirect('/toohigh')
    elif guessednumber < session['randomnum']:
        return redirect('/toolow')

# @app.route('/yougotit')
# def gotit():

# @app.route('/')

# @app.route('/')




if __name__ == "__main__":
    app.run(debug=True)
