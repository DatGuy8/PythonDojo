
from flask import Flask, render_template, session, redirect, request
app = Flask(__name__)
app.secret_key = 'BOOMSHAKALAKAPOW'


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/process', methods=['POST'])
def getinfo():
    print('GOT THE INFO')
    print(request.form)
    session['userdata'] = request.form
    return redirect('/results')

@app.route('/results')
def showinfo():
    print(session['userdata'])
    return render_template('results.html')





if __name__=="__main__":
    app.run(debug=True)
